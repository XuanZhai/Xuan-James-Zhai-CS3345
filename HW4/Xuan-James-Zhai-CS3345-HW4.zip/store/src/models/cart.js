
export class Cart{
    items;
    total;
    constructor(){
        this.items = [];
        this.total = 0;
    }
}