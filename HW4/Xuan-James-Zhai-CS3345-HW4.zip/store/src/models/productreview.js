


export class ProductReview{
    userName;
    rating;
    comment;
    date;
    constructor(userName, rating, comment, date){
        this.userName = userName;
        this.rating = rating;
        this.comment = comment;
        this.date = date;
    }
}