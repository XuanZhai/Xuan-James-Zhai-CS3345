import React from 'react';
import ReactDOM from "react-dom";
import ProductDetails from './productDetails';

class App extends React.Component {

    render () {
      return (
        <ProductDetails />
      )
    }
}


export default App